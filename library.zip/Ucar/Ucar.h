/*
  Ucar.h - Library for supbizel racing car
  Created by Davide Caminati, August 22, 2019.
  Released into the public domain.
*/
#ifndef Ucar_h
#define Ucar_h

#include "Arduino.h"

class Ucar
{
  public:
    Ucar(int _color,int _x, int _y, int _penality,String _name);
	int color;
	int x;
	int y;
	int penality;
	String name;
};


#endif