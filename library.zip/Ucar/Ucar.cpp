/*
  Ucar.h - Library for supbizel racing car
  Created by Davide Caminati, August 22, 2019.
  Released into the public domain.
*/

#include "Arduino.h"
#include "Ucar.h"

Ucar::Ucar(int _color,int _x, int _y,int _penality,String _name)
{
  color = _color;
  x = _x;
  y = _y;
  penality = _penality;
  name = _name;
}
